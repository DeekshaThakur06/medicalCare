package com.medical.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.medical.domain.Medicine;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service("medicalService")
@Scope("singleton")
public class MedicalService {

	@Autowired
	private RestTemplate restTemplate;
	@HystrixCommand(fallbackMethod="fallbackMethodMedicineById")
	public Medicine getMedicineById(int id) {
		
		Medicine medicine = restTemplate.getForObject("http://medical-service/medicines" + id, Medicine.class);
		return medicine;
		
	}
public Medicine fallbackMethodMedicineById(int id) {
		
		 
		return new Medicine(id,"Paracetamol","Cipla",15,8000);
		
	}
}
