package com.medical.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medical.domain.Medicine;
import com.medical.proxy.MedicalServiceProxy;

@RestController
@Scope("request")
public class MedicalClientController {

	@Autowired
	private MedicalServiceProxy medicalServiceProxy;
	
	@GetMapping(value="/get-medicines",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<Medicine> getAll(){
	return medicalServiceProxy.getAllMedicines();
	}
	
	@GetMapping(value="/get-medicines/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Medicine getById(Integer id) {
	return medicalServiceProxy.getMedicinesById(id);
	}
    
	@DeleteMapping(value="/get-delete/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public void deleteMedicinesById(Integer id)
	{ medicalServiceProxy.deleteMedicinesById(id);}
	
	@PostMapping(value="/get-add",produces= {MediaType.APPLICATION_JSON_VALUE},consumes={MediaType.APPLICATION_JSON_VALUE})
	public Medicine saveMedicines(Medicine medicine) {
		return medicalServiceProxy.addMedicines(medicine);
	}
	
    @PutMapping(value="/get-update",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Medicine updateMedicines(Medicine medicine) {
    	return medicalServiceProxy.updateMedicines(medicine);
    }
}
