package com.medical.proxy;

import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.medical.domain.Medicine;

public interface MedicalServiceProxy {

	@GetMapping(value="/medicines",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<Medicine> getAllMedicines();
	
	@GetMapping(value="/medicines/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Medicine getMedicinesById(Integer id);
    
	@DeleteMapping(value="/delete/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public void deleteMedicinesById(Integer id);
	
	@PostMapping(value="/add",produces= {MediaType.APPLICATION_JSON_VALUE},consumes={MediaType.APPLICATION_JSON_VALUE})
	public Medicine addMedicines(Medicine medicine);
    
	@PutMapping(value="/update",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Medicine updateMedicines(Medicine medicine);
}
