package com.medical;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.medical.domain.Medicine;
import com.medical.repository.MedicineRepository;

@EnableEurekaClient
@SpringBootApplication
public class BioMedicalCareApplication implements CommandLineRunner{

	@Autowired
	@Qualifier("medicineRepository")
	private MedicineRepository medicineRepository;
	public static void main(String[] args) {
		SpringApplication.run(BioMedicalCareApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
medicineRepository.save(new Medicine(00,"Paracetamol", "Cipla", 10, 1000));
medicineRepository.save(new Medicine(00,"Disprin", "XYA", 50, 5000));	
medicineRepository.save(new Medicine(0," Combiflame", "abc", 85, 10000));
medicineRepository.save(new Medicine(00,"AboMIne", "Cipla", 50, 5000));
		System.out.println(medicineRepository.findAll());
	}

}
